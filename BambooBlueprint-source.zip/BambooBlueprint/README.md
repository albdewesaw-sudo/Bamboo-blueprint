# Bamboo Blueprint — Fabric 1.21.11 prototype

This is the **source project** for the first prototype of Bamboo Blueprint, intended for Minecraft Java 1.21.11 with Fabric on Mojo Launcher (Android).

## What this prototype does
- Client-only Fabric mod entry point.
- Press **K** to toggle a cyan/green wireframe preview for eight parallel planting rows.
- The preview is positioned a few blocks in front of the player.

## What it does not do yet
- It does not place blocks or automatically build the farm.
- It does not include the observer/piston circuit or item collection yet.
- The source has not been compiled or tested in-game in this environment.

## Build requirements
- Java 21
- Gradle (the Fabric Loom build downloads Minecraft/Fabric dependencies)
- Minecraft 1.21.11 and matching Fabric Loader/API

From this folder, run `gradle build` after installing Gradle. The mod jar will be in `build/libs/`.

## Install on Mojo Launcher
Once compiled, copy `bamboo-blueprint-0.1.0.jar` into the `mods` folder for the Minecraft 1.21.11 Fabric profile. Keep Fabric API installed too. Launch a test single-player world and press **K** to toggle the preview.

## Notes
The wireframe is a visual footprint preview, not a validated farm schematic. The next development step is to add an explicit placement/orientation UI, then implement and test the observer/piston harvesting module and collection channels before enabling any automatic placement.
