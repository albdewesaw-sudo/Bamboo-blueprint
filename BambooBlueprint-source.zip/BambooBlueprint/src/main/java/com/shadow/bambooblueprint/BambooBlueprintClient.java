package com.shadow.bambooblueprint;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/**
 * Bamboo Blueprint 0.1.0 — preview-only prototype.
 * Press K to toggle the eight-row farm footprint hologram.
 * This first build deliberately does not place blocks yet.
 */
public final class BambooBlueprintClient implements ClientModInitializer {
    private static boolean hologramEnabled = true;
    private static KeyMapping toggleKey;

    // Farm dimensions in blocks. Eight parallel rows, each 9 blocks long.
    private static final int ROWS = 8;
    private static final int ROW_LENGTH = 9;
    private static final int ROW_SPACING = 2;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.bamboo_blueprint.toggle_hologram",
                GLFW.GLFW_KEY_K,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                hologramEnabled = !hologramEnabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal("Bamboo Blueprint hologram: " + (hologramEnabled ? "ON" : "OFF")),
                            true
                    );
                }
            }
        });

        WorldRenderEvents.LAST.register(context -> {
            Minecraft client = Minecraft.getInstance();
            if (!hologramEnabled || client.level == null || client.player == null) return;

            // Place the preview a few blocks in front of the player, aligned to the block grid.
            Vec3 look = client.player.getLookAngle();
            BlockPos anchor = BlockPos.containing(
                    client.player.getX() + look.x * 4.0,
                    client.player.getY(),
                    client.player.getZ() + look.z * 4.0
            );
            anchor = new BlockPos(anchor.getX(), client.player.blockPosition().getY(), anchor.getZ());

            PoseStack matrices = context.matrixStack();
            MultiBufferSource consumers = context.consumers();
            if (matrices == null || consumers == null) return;

            Vec3 camera = context.camera().getPosition();
            matrices.pushPose();
            matrices.translate(-camera.x, -camera.y, -camera.z);
            var lines = consumers.getBuffer(RenderType.lines());

            // Cyan outline around each planting strip; these are preview outlines only.
            for (int row = 0; row < ROWS; row++) {
                int zOffset = row * ROW_SPACING;
                AABB rowBox = new AABB(
                        anchor.getX(), anchor.getY(), anchor.getZ() + zOffset,
                        anchor.getX() + ROW_LENGTH, anchor.getY() + 1.0, anchor.getZ() + zOffset + 1.0
                );
                LevelRenderer.renderLineBox(matrices, lines, rowBox, 0.15f, 0.75f, 1.0f, 0.95f);

                // Small upright markers show the intended bamboo positions.
                for (int x = 0; x < ROW_LENGTH; x++) {
                    AABB plantMarker = new AABB(
                            anchor.getX() + x + 0.25, anchor.getY(), anchor.getZ() + zOffset + 0.25,
                            anchor.getX() + x + 0.75, anchor.getY() + 2.0, anchor.getZ() + zOffset + 0.75
                    );
                    LevelRenderer.renderLineBox(matrices, lines, plantMarker, 0.1f, 0.95f, 0.65f, 0.7f);
                }
            }
            matrices.popPose();
            if (consumers instanceof MultiBufferSource.BufferSource bufferSource) {
                bufferSource.endBatch(RenderType.lines());
            }
        });
    }
}
